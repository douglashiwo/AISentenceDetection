# SegFormer for the CoAuthor dataset
SegFormer: A Topic Segmentation Model with Controllable Range of Attention


## 1. Install running environment
Use conda to create a new environment, python version 3.8 is recommended.

It is recommended to use the official cuda, cudnn, and torch environments.

Then,install software dependencies using pip install -r requirements.txt

We use the transformer framework and develop in an editable way. 
```shell
cd .../transformers/  

pip install --editable .
```

It is recommended to use two and more GPUs

## 2. To reduce GPU memory usage and accelerate training

* Reducing the block_size {16,24,32} and batch_size can reduce the use of GPU memory, which may cause performance loss. 

* Increasing the logging_steps and save_steps can accelerate the training speed, but it may also cause performance loss.



## 3. Datasets
* Place the `.xlsx` of coauthor data under the `dataset` folder.

* Run `python coathor_to_segf_train_data.py --dataset coauthor` with the following parameters, which allow you to choose between the full data and a subset of test data ('coauthor', 'coauthor_test').

* Please note that the location of the output data is in the project folder named coauthor or coauthor_test.


## 4. Training scrips


* Before training, make sure you set `is_output_sent_label = False` in `transformers/src/transformers/models/bert/modeling_bert.py` ,

```bash
# train coauthor_real
python -m torch.distributed.launch --master_port 11111 --nproc_per_node=2 run_language_modeling.py --output_dir=dir/ --model_type=bert --model_name_or_path=bert-base-uncased --do_train --do_eval --evaluate_during_training --train_data_file=coauthor_real/train/ --eval_data_file=coauthor_real/val/ --line_by_line --block_size 48 --num_train_epochs 25 --learning_rate 1e-5 --warmup_steps 100 --logging_steps 5 --save_steps 5 --per_device_train_batch_size 2 --gradient_accumulation_steps 4 --overwrite_output_dir --evaluation_strategy=steps --per_device_eval_batch_size 10 --con_loss --yuzhi 0.5 --choice 0 --label_num 3 --save_total_limit 1 --English

```
* logging_steps Used to control how many steps to test and save.

* The training code will save the best kappa value checkpoint on the valid dataset.

* You can set different weight of two loss function to 1 or 0
in the model code`transformers/src/transformers/models/bert/modeling_bert.py`.


## 5. Testing scrips
Before testing, make sure you set `is_output_sent_label = True` in `transformers/src/transformers/models/bert/modeling_bert.py`,
It will output labels of sentence level.

then, move these files into model_save_path:

    --pytorch_model.bin  
    --config.json  
    --special_tokens_map.json  
    --tokenizer_config.json  
    --tokenizer.json  
    --vocab.txt  

run follow script,

```bash
# The number of test set documents in the following command, as well as the number of tags, and the number of tags in the meties in `test.py` need to be changed
python test.py --model_type=bert  --output_dir=dir --model_name_or_path=./save_train_data/1_alp0_checkpoint-515 --do_eval --eval_data_file=coauthor/test/ --line_by_line --block_size 48 --per_device_eval_batch_size 2 --English --dataset_size 127 --label_num 3 --con_loss
```


