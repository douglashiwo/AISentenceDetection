import os

import pandas as pd
import nltk
from openpyxl import load_workbook
import argparse, shutil, logging

# Make sure you have downloaded NLTK's word segmentation resource
# nltk.download('punkt')
from tqdm import tqdm

num=0
seg_list=[]
len_list=[]
seg_num=0
all_labels={}

def transfer(table):
    have=[]
    count=0
    sentence_list=[]
    author_label_list=[]
    # boundary is the last sentence of the last segment
    boundary_list=[]
    global all_labels
    label=''
    #
    for index, row in table.iterrows():
        author_label = row['label']
        sentence_text = row['sentence_text']
        sentence_list.append(sentence_text)
        author_label_list.append(author_label)
        count += 1
    for i in range(len(author_label_list)):
        if i != len(author_label_list) - 1 and author_label_list[i] != author_label_list[i + 1] :
            boundary_list.append(1)
        else:
            boundary_list.append(0)
    return sentence_list,author_label_list,boundary_list[:-1],count

def reorder_dataframe(df, column_name):
    if column_name not in df.columns:
        raise ValueError(f"Column '{column_name}' does not exist in the DataFrame")
    train_rows = df[df[column_name] == 'train']
    valid_rows = df[df[column_name] == 'valid']
    test_rows = df[df[column_name] == 'test']
    # train_rows = train_rows.sort_index()
    # valid_rows = valid_rows.sort_index()
    # test_rows = test_rows.sort_index()
    return train_rows,valid_rows,test_rows
def divide_folder(data_table, out_folder):
    # Read this table file and then read the articles in the order in which they were written
    global seg_num
    global seg_list
    global num
    all_count=0
    all_count_num=0
    # Group by session_id
    # Convert session_id columns to Categorical type and sort using the order of the original table
    data_table['session_id'] = pd.Categorical(data_table['session_id'], categories=data_table['session_id'].unique(),
                                              ordered=True)
    # Use groupby for grouping
    grouped = data_table.groupby('session_id')
    # Initialise a list to store the grouped tables
    table_list = []
    # Iterate through the groupings and store the data from each grouping into a new table, then add the table to the list
    for name, group in grouped:
        table_list.append(group.copy())

    # Split the table into tables according to the sessionid, then process each table independently
    if os.path.exists(out_folder + 'text/'):
        pass
    else:
        os.makedirs(out_folder + 'text/')
        os.makedirs(out_folder + 'label1/')
        os.makedirs(out_folder + 'label2/')

    for table in tqdm(table_list, desc="Processing tables", unit="table"):
        sentence_lsit, author_label_list, boundary_list,count = transfer(table)
        if count!=0:
            all_count+=1
            all_count_num+=count
        num += 1
        if len(boundary_list)!=0:
            # Following the previous work (Transformer over Pre-trained Transformer for Neural Text Segmentation with Enhanced Topic Coherence),
            # we set the max input length to 150. Otherwise, the required GPU memory is unacceptable.
            if len(author_label_list)>150:
                # txt list
                sentence_lsit=sentence_lsit[:150]
                # boundary_list
                boundary_list = boundary_list[:149]
                # content list
                author_label_list = author_label_list[:150]
            with open(out_folder + 'text/' + str(num) + '.txt', 'w', encoding='utf-8') as f:
                f.writelines([str(line) + '\n' for line in sentence_lsit])
            with open(out_folder + 'label1/' + str(num) + '.txt', 'w', encoding='utf-8') as f:
                f.writelines([str(line) + '\n' for line in boundary_list])
            with open(out_folder + 'label2/' + str(num) + '.txt', 'w', encoding='utf-8') as f:
                f.writelines([str(line) + '\n' for line in author_label_list])
            len_list.append(len(sentence_lsit))
            seg_length = 1
            boundary_list.append(1)
            for i in range(len(boundary_list)):
                if boundary_list[i] == 1:
                    seg_list.append(seg_length)
                    seg_num += 1
                    seg_length = 1
                else:
                    seg_length += 1
        else:
            pass
    return all_count,all_count_num

def divide(train,val,test,path):
    global all_labels
    all_count,all_count_num=divide_folder(train,path+ 'train/')
    print(train)
    print(all_count)
    print(all_count_num)
    print(all_labels)
    all_count,all_count_num=divide_folder(val,path+'val/')
    print(val)
    print(all_count)
    print(all_count_num)
    print(all_labels)
    all_count,all_count_num=divide_folder(test,path+ 'test/')
    print(test)
    print(all_count)
    print(all_count_num)
    print(all_labels)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    # we = writing essay dataset
    parser.add_argument('--dataset', default='coauthor_test', choices=['coauthor', 'coauthor_test'])
    args = parser.parse_args()
    dataset = args.dataset
    if dataset == "coauthor":
        dataset_path = './dataset/20231114_coauthor_data.xlsx'
    elif dataset == "coauthor_test":
        dataset_path = './dataset/20231114_coauthor_data_test.xlsx'
    data_table = pd.read_excel(dataset_path, engine='openpyxl')
    # Filter out the data and create a copy to avoid SettingWithCopyWarning
    # 0 is user, 1 is api, 2 is user and api
    selected_data_table = data_table[
        (data_table['label'].isin([0, 1, 2])) &
        (data_table['train_ix'].isin(['train', 'test','valid']))
    ].copy()
    train_rows,valid_rows,test_rows = reorder_dataframe(selected_data_table,"train_ix")

    train_rows, valid_rows, test_rows = reorder_dataframe(selected_data_table,"train_ix")

    divide(train_rows, valid_rows, test_rows,path = f"./{dataset}/")
    print(dataset+" Files have been successfully saved.")
