Place the wikisection json files here.
The dataset can be found <a href='https://github.com/sebastianarnold/WikiSection' target='_blank'>here</a>.