import pandas as pd
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, cohen_kappa_score


def save_test_dataset_data(prediction_data,raw_predicted_test_data,predicted_test_data_save_path):

    data_table = read_dataset_xlsx(raw_predicted_test_data)
    merged_data = pd.concat([data_table.reset_index(drop=True), prediction_data.reset_index(drop=True)], axis=1)
    # Save as xlsx file
    merged_data.to_excel(predicted_test_data_save_path, index=False)
#    可以算一下准确度之类的

def save_test_dataset_data(prediction_data,raw_predicted_test_data,predicted_test_data_save_path):

    data_table = read_dataset_xlsx(raw_predicted_test_data)
    merged_data = pd.concat([data_table.reset_index(drop=True), prediction_data.reset_index(drop=True)], axis=1)
    # Save as xlsx file
    merged_data.to_excel(predicted_test_data_save_path, index=False)
#    可以算一下准确度之类的

def read_dataset_xlsx(data_path):
    data_table = pd.read_excel(data_path, engine='openpyxl')

    selected_data_table = data_table[
        (data_table['label'].isin([0, 1, 2])) &
        (data_table['train_ix'].isin(['train', 'test', 'valid']))
        ].copy()
    selected_data_table_sorted = reorder_dataframe(selected_data_table, "train_ix")
    test_dataset = selected_data_table_sorted.loc[
        selected_data_table_sorted['train_ix'] == 'test'
        ].copy()
    test_dataset = test_dataset.reset_index(drop=True)
    return test_dataset

def reorder_dataframe(df, column_name):
    if column_name not in df.columns:
        raise ValueError(f"Column '{column_name}' does not exist in the DataFrame")
    train_rows = df[df[column_name] == 'train']
    valid_rows = df[df[column_name] == 'valid']
    test_rows = df[df[column_name] == 'test']
    reordered_df = pd.concat([train_rows, valid_rows, test_rows], ignore_index=True)
    return reordered_df

def comput_metrics(y_test_true_results,y_test_pred_results,result_type,corpus,t2_model_name,save_xlxs_path):
    prediction_data = pd.DataFrame({'label_': y_test_true_results, 'label_preds': y_test_pred_results})
    accuracy = accuracy_score(y_test_true_results, y_test_pred_results)
    precision = precision_score(y_test_true_results, y_test_pred_results, average='macro')  # 'macro'表示未加权的平均值
    recall = recall_score(y_test_true_results, y_test_pred_results, average='macro')
    f1 = f1_score(y_test_true_results, y_test_pred_results, average='macro')
    kappa = cohen_kappa_score(y_test_true_results, y_test_pred_results)

    # 打印结果
    results_dic = {"Accuracy":accuracy}
    results_dic.update({"Precision":precision})
    results_dic.update({"Recall":recall})
    results_dic.update({"F1_Score":f1})
    results_dic.update({"Kappa":kappa})

    print(f'Accuracy: {accuracy}')
    print(f'Precision: {precision}')
    print(f'Recall: {recall}')
    print(f'F1_Score: {f1}')
    print(f'Kappa: {kappa}')

    if "author" in corpus:
        raw_predicted_test_data = "data/wikisection/20231114_coauthor_data.xlsx"
        predicted_test_data_save_path = save_xlxs_path+f"/{result_type}_coauthor_data_predicted.xlsx"
        save_test_dataset_data(prediction_data, raw_predicted_test_data, predicted_test_data_save_path)
    return results_dic
