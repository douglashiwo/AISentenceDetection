#!/bin/bash

cd /home/sliu0233/uq67/liushiqi_project/Transformer2CoA/
# ssh m3a100
module load cudnn/8.0.5-cuda11; module load anaconda/2020.07-Python3.8-gcc8; export PROJECT=uq67; export CONDA_ENVS=/scratch/$PROJECT/$USER/conda_envs;source activate $CONDA_ENVS/lsq_t2
#python create_label_dict.py --corpus en_coauthor
python prepare_single_sentence_embeddings.py --model BERT --corpus en_coauthor --max_sent 256 --tf T
python prepare_pairwise_sentence_embeddings.py --model BERT --corpus en_coauthor --max_sent 256 --tf T

python transformer_squared_single_pairwise.py --model BERT --corpus en_coauthor --attn_head 24 --epoch 300 --batch_size 32 --mask_b_rate 1 --mask_i_rate 1 --train_step 100 --val_step 100 --encoder_layers 5 --encoder_dff 1024
#python transformer_squared_single_pairwise.py --model BERT --corpus en_coauthor --attn_head 24 --epoch 300 --batch_size 32 --mask_b_rate 1 --mask_i_rate 0.7 --train_step 100 --val_step 100 --encoder_layers 5 --encoder_dff 1024

