import pandas as pd
from tqdm import tqdm


def transfer(table):
    have=[]
    count=0
    sentence_list=[]
    author_label_list=[]
    # boundary是指最后一个段落的最后一句
    boundary_list=[]
    global all_labels
    label=''
    #
    for index, row in table.iterrows():
        author_label = row['label']
        sentence_text = row['sentence_text']
        sentence_list.append(sentence_text)
        author_label_list.append(author_label)
        count += 1
    for i in range(len(author_label_list)):
        if i != len(author_label_list) - 1 and author_label_list[i] != author_label_list[i + 1] :
            boundary_list.append(1)
        else:
            boundary_list.append(0)
    return sentence_list,author_label_list,boundary_list,count

def reorder_dataframe(df, column_name):
    if column_name not in df.columns:
        raise ValueError(f"Column '{column_name}' does not exist in the DataFrame")
    train_rows = df[df[column_name] == 'train']
    valid_rows = df[df[column_name] == 'valid']
    test_rows = df[df[column_name] == 'test']
    return train_rows,valid_rows,test_rows

def divide_folder(data_table):
    # 读取这个表格文件，然后按文章的顺序
    global seg_num
    global seg_list
    global num
    all_count=0
    all_count_num=0
    # 根据 session_id 分组
    data_table['session_id'] = pd.Categorical(data_table['session_id'], categories=data_table['session_id'].unique(),
                                              ordered=True)

    # 使用groupby进行分组
    grouped = data_table.groupby('session_id')
    # 初始化一个列表来存储分组后的表格
    table_list = []
    # 遍历分组，并将每个分组的数据存储到一个新表格，然后将表格添加到列表

    for name, group in grouped:
        table_list.append(group.copy())
    # 把表格按照sessionid分成很多个table，然后独立处理每个table
    data_set = []
    for table in tqdm(table_list, desc="Processing tables"):
        sentence_list,author_label_list,boundary_list,count = transfer(table)
        assert len(sentence_list) == len(author_label_list) == len(boundary_list)
        # 使用列表推导式创建格式化后的列表
        formatted_list = [
            {'text': sentence, 'topic_label': author_label, 'start_label': boundary}
            for sentence, author_label, boundary in zip(sentence_list, author_label_list, boundary_list)
        ]
        #         sentences = [sentence['text'] for sentence in article]
        #         topic_labels = [sentence['topic_label'] for sentence in article]
        #         start_labels = [sentence['start_label'] for sentence in article]
        data_set.append(formatted_list)
    return data_set


def divide(train,val,test):
    global all_labels
    train_dataset =divide_folder(train)

    val_dataset=divide_folder(val)

    test_dataset=divide_folder(test)
    return train_dataset,val_dataset,test_dataset

def get_table_data(original_path):
    print("read data begin")

    # we = writing essay dataset
    dataset = "coauthor_test"
    dataset_path = original_path+'20231114_coauthor_data.xlsx'

    data_table = pd.read_excel(dataset_path, engine='openpyxl')
    # Filter out the data and create a copy to avoid SettingWithCopyWarning
    # 0 is user, 1 is api, 2 is user and api
    selected_data_table = data_table[
        (data_table['label'].isin([0, 1, 2])) &
        (data_table['train_ix'].isin(['train', 'test','valid']))
    ].copy()
    train_rows,valid_rows,test_rows = reorder_dataframe(selected_data_table,"train_ix")

    train_dataset,val_dataset,test_dataset = divide(train_rows, valid_rows, test_rows)
    print("read data return !")

    return train_dataset,val_dataset,test_dataset

if __name__ == '__main__':
    train_dataset,val_dataset,test_dataset = get_table_data()

#     sentences = [sentence['text'] for sentence in train_dataset]
#     topic_labels = [sentence['topic_label'] for sentence in train_dataset]
#     start_labels = [sentence['start_label'] for sentence in train_dataset]
# #             data_set.append(formatted_list)
