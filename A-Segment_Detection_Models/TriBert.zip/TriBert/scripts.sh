

CUDA_VISIBLE_DEVICES=1 python -u code.py --num_epochs 10  --bry_candidate_ratio 1.0 --learning_rate 0.00002 --data_file data.xlsx  --examples_per_epoch 5000 --save_model 0  --prototype_size 1 --run_ix a &> lr00002_ratio_1.0_5000_ix_a.txt

