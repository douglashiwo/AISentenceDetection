
# we dataset distribution
 `we` means writing essay dataset.

`20231114_coauthor_data.xlsx`  contains all the dataset.



Train Size: 24314, Validation Size: 5302, Test Size: 5609


# we_test dataset distribution

`20231114_coauthor_data_test.xlsx`  contains part the dataset, 
which can be used to debug model quickly.

Train Size:2183 , Validation Size:  327 ,Test Size:  490