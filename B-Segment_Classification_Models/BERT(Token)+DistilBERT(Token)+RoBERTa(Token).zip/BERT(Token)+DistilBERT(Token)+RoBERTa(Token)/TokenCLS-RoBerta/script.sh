



CUDA_VISIBLE_DEVICES=0 python -u code.py --num_epochs 10 --learning_rate 0.00002 --data_file data.xlsx --run_ix a --examples_per_epoch 20000 --save_model 0 --model_name roberta-base &>Token_CLS_Coauthor_00002_20000_a.txt


