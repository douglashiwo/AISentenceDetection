

# Run the following script and you will obtain the sentence-level prediction for each sentence from the Co-author dataset (data.xlsx).

# Then, you might choose to combine with the output of the segment detection model to determine the FINAL PREDICTION MODEL.

# For example, if the sentence-level prediction for segment S =  <s1,s2,s3,s4> is <Human,Human,AI-written,Human>. And the segment detection model consider S as a single segment. Then you might consider to alter the prediction from <Human,Human,AI-written,Human> to <Human,Human,Human,Human>, given that the segment detection model believe all <s1,s2,s3,s4> should have the same label (we simply choose the majaority as prediction).

#Note that this is only an example of combining segment detection model and segment classification model into a single pipeline. One can choose other approaches to combine the benefits of the two.


CUDA_VISIBLE_DEVICES=1 python -u code.py --num_epochs 10 --learning_rate 0.00002 --data_file data.xlsx --run_ix a --examples_per_epoch 20000 --save_model 0 &> chunk_Yes_1.0-a.txt






