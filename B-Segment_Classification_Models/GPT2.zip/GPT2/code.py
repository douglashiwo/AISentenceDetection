from transformers import AdamW
from transformers import get_scheduler
from transformers import AutoModelForSequenceClassification
from datasets import load_dataset
from transformers import AutoTokenizer
from datasets import Dataset
from nltk.tokenize import sent_tokenize
from sklearn.metrics import roc_curve, roc_auc_score, auc,precision_score, f1_score, accuracy_score, recall_score
from sklearn.metrics import cohen_kappa_score
#import ml_metrics as metrics
import datetime
import numpy as np
import torch
import time, os
import random
from sentence_transformers import SentenceTransformer, LoggingHandler, losses, InputExample
from torch.utils.data import DataLoader
import pandas as pd
import random, ast
from scipy.spatial import distance
import argparse
import datasets
from bry import TriBertForBoundaryDetection


datasets.disable_progress_bar()

def get_sentence(text):
    """
    from nltk.tokenize import sent_tokenize
    import nltk
    """
    res = sent_tokenize(text)
    return [s.replace('\n',' ').strip() for s in res]



def get_euclidean_distance(v1,v2):
    return distance.euclidean(v1,v2)



def get_one_single_bert_example(data): # checked
    
    ran = random.random()
    
    if ran < 0.33333:
        src = 'user'
    elif ran < 0.66666:
        src = 'api'
    else:
        src = 'user_and_api'
        
    random_record = data[#(data.prompt_code == prompt_code) 
                            #& 
                            (data.train_ix == 'train') 
                            & 
                            (data.sentence_source != 'prompt')
                            &
                            (data.sentence_source == src)
                        ].sample(n = 1).to_dict(orient='records')
    
    text_lbl=[(e['sentence_text'],e['label']) for e in random_record]
    #text_combined = " ".join([text for text, lbl in text_lbl])
    text_combined = text_lbl[0][0]
    lbl = text_lbl[0][1]
    
    example = (text_combined, lbl)
    return example
    

    
def get_n_bert_examples(data, examples_per_epoch): # checked
    res=[]
    for i in range(examples_per_epoch):
        res.append( get_one_single_bert_example(data) )
        
    return res

def get_one_bert_epoch_data(data, examples_per_epoch, tokenizer): # checked
    
    #tokenizer = AutoTokenizer.from_pretrained("bert-base-cased")
    
    d = get_n_bert_examples(data = data, examples_per_epoch = examples_per_epoch)
    
    epoch_df = pd.DataFrame()
    essay_series, lbl_series= pd.Series(  [sent for sent, lbl in d] ), pd.Series(  [lbl for sent, lbl in d] )
    epoch_df['sent'] = essay_series
    epoch_df['lbl'] = lbl_series

    dataset = Dataset.from_pandas(epoch_df)
    tokenized_datasets = dataset.map(
                                lambda x: tokenizer(x["sent"], padding="max_length", truncation=True)
                                 , batched = True
                                )
    tokenized_datasets = tokenized_datasets.map(
                                    lambda x : {'labels' : x['lbl']}
                                    )

    cols_to_remove = [col for col in tokenized_datasets.features.keys() if col not in ('attention_mask','input_ids','token_type_ids','labels')]
    tokenized_datasets = tokenized_datasets.remove_columns(cols_to_remove)
    tokenized_datasets.set_format("torch")
    dataloader = DataLoader(tokenized_datasets, shuffle = True, batch_size = 1)
    
    return dataloader 


def train_one_epoch(model, train_loader, lr_scheduler, optimizer, accumulation_steps=16):#checked
    
    #print('---------Training Epoch begins ----time: {}'.format(str(datetime.datetime.now())[:19]))
    cnt = 0
    
    for batch in train_loader:

        batch = {k: v.to(device) for k, v in batch.items()}
        outputs = model(**batch)
        loss = outputs.loss / accumulation_steps  

        cnt += 1
        loss.backward()

        if cnt % accumulation_steps == 0:
            optimizer.step()
            lr_scheduler.step()
            optimizer.zero_grad()

    optimizer.step()
    #lr_scheduler.step()
    optimizer.zero_grad()
    #print('---------Training Epoch ends ----time: {}'.format(str(datetime.datetime.now())[:19]))
    

def convert_sents_to_loader(sents, tokenizer):  # checked
    
    #sents = get_sentence(essay)
    sent_df = pd.DataFrame()
    sent_df['sent'] = pd.Series( sents )
    
    dataset = Dataset.from_pandas(sent_df)
    tokenized_datasets = dataset.map(
                                lambda x: tokenizer(x["sent"], padding="max_length", truncation = True)
                                 , batched = True
                                )
    
    
    cols_to_remove = [col for col in tokenized_datasets.features.keys() if col not in ('attention_mask','input_ids','token_type_ids')]
    tokenized_datasets = tokenized_datasets.remove_columns(cols_to_remove)
    
    tokenized_datasets.set_format("torch")
    dataloader = DataLoader(tokenized_datasets, shuffle = False, batch_size = 1)
    
    return dataloader



def labels_list_to_labels_chunk_with_majority(labels, boundaries):

    boundaries = sorted(boundaries)
    chunk_ixs = [0] + boundaries + [len(labels)] 
    labels_chunk = []   
    
    for ix, e in enumerate(chunk_ixs[:-1]):
        labels_slice = labels[chunk_ixs[ix]:chunk_ixs[ix + 1]] 
        labels_chunk.append(labels_slice)
        
    res_list = []    
    for cunk in labels_chunk:
        elements_in_the_chunk = set(cunk)
        element_and_count = []
        
        for e in elements_in_the_chunk:
            l = [x for x in cunk if x == e]
            element_and_count.append( ( e, len(l) ) )  
        majority_label_for_this_chunk = sorted(element_and_count, key = lambda x:x[1], reverse = True)[0][0] 
        majority_label = [majority_label_for_this_chunk for e in range(len(cunk))]
        res_list += majority_label   
    
    return res_list
 

def predict_label_for_one_essay_using_Bert(model, sents, tokenizer, predict_as_chunk = 0, bry_for_this_sents = None): # checked
        
    sent_loader = convert_sents_to_loader(sents, tokenizer)
    sent_predictions = []

    for batch in sent_loader:
        batch = {k: v.to(device) for k, v in batch.items()}
        with torch.no_grad():
            outputs = model(**batch)

        predictions = torch.argmax(outputs.logits, dim=-1).item()
        sent_predictions.append(predictions)
        
    if predict_as_chunk == 0:    
        return np.array(sent_predictions).flatten().tolist()
              
    elif predict_as_chunk == 1:          
        res = np.array(sent_predictions).flatten().tolist()  
        return labels_list_to_labels_chunk_with_majority(res, bry_for_this_sents)




def get_evaluation_result(predicted, lbls):  # all are list of lists
    
    tpl = list(zip(predicted, lbls))
    all_acc = []
    all_pred = []
    all_rec = []
    all_f1 = []
    all_kappa = []
    
    unified_predicted=[]
    unified_lbls=[]
    
    for p, l in tpl:
        unified_predicted += p
        unified_lbls += l
        all_acc.append(round(accuracy_score(l, p),3))
        all_pred.append(round(precision_score(l, p, average = 'macro' ),3))
        all_rec.append(round(recall_score(l, p, average = 'macro'),3))
        all_f1.append(round(f1_score(l, p, average = 'macro'),3))
        
    kappa = round(cohen_kappa_score(unified_lbls, unified_predicted), 3)
    
    return kappa, round( np.mean(all_acc), 3), round( np.mean(all_pred), 3), round( np.mean(all_rec), 3), round( np.mean(all_f1), 3)
    
    
    
def get_bry_from_labels(label_list): #checked
    brys = []
    for ix,lbl in enumerate(label_list[:-1]):
        if label_list[ix] != label_list[ix+1]:
            brys.append(ix+1)
            
    return brys
    


def get_sessions_essays_brys(df):   #checked
    all_essays = []
    all_brys = []
    all_labels= []
    all_sessions = list(df['session_id'])

    res=[]
    for e in all_sessions:
        if e not in res:
            res.append(e)
    all_sessions = res    

    for session in all_sessions:
        single_essay = df[df.session_id==session].sort_values(by = 'sent_id', ascending=True)['sentence_text'].tolist()
        single_label = df[df.session_id==session].sort_values(by = 'sent_id', ascending=True)['label'].tolist()
        single_brys = get_bry_from_labels( single_label ) 

        
        all_essays.append(single_essay)
        all_brys.append(single_brys)  
        all_labels.append(single_label)
        
    return all_sessions, all_essays, all_brys, all_labels



def evaluate_BERT_model(model, data, test_type): #checked
    print('--------Start Evaluating: {}--------'.format(str(datetime.datetime.now())[:19]))
    t1 = time.time()
    if test_type == 'valid':
        
        
        prompt_data = data[
            (data.train_ix == 'valid') & (data.sentence_source != 'prompt')
            #&
            #(data.rn_ratio > 0.82)
        ]
        
        
    elif test_type == 'test':  # that is 'test' type on unseen prompt
        prompt_data = data[
            (data.train_ix == 'test') & (data.sentence_source != 'prompt') #& (data.rn_ratio > 0.97)
        ]
             
        
    all_predicted_labels = []
    all_sessions, all_essays, all_bry_labels, all_labels = get_sessions_essays_brys(prompt_data)
    all_top_brys =[]
    all_ranked_brys = []
    for essay in all_essays:
    
        #if predict_as_chunk==1:
        top_boundaries, ranked_boundaries = bry_model.predict_boundary_for_one_essay(essay)
        all_ranked_brys.append(ranked_boundaries)
        all_top_brys.append(top_boundaries)
        all_predicted_labels.append(predict_label_for_one_essay_using_Bert(model, essay, 
                                                            tokenizer, predict_as_chunk = predict_as_chunk,
                                                            bry_for_this_sents = top_boundaries
                                                            )
                                   )
        
        
    kappa, acc, precision, recall, f1_score = get_evaluation_result(all_predicted_labels, all_labels)
    
    print('--------------------{}ing------------------------'.format(test_type))
    print('Kappa: {}'.format(kappa))
    print('Accuracy: {}'.format(acc))
    print('Precision: {}'.format(precision))
    print('Recall: {}'.format(recall))
    print('f1_score: {}'.format(f1_score))
        
    if test_type == 'test':
        result_file = 'lr_{}_predicted_results_{}_chunk_{}_ratio_{}_run_{}.xlsx'.format(lr, examples_per_epoch, predict_as_chunk, bry_candidate_ratio, run_ix)
        res_df = pd.DataFrame()
        
        res_df['session_id'] = pd.Series(all_sessions)
        res_df['essay_sents'] = pd.Series(all_essays)
        res_df['labels'] = pd.Series(all_labels)
        res_df['predicted'] = pd.Series(all_predicted_labels)
        #if predict_as_chunk==1:
        res_df['top_brys'] = pd.Series(all_top_brys)
        res_df['ranked_brys'] = pd.Series(all_ranked_brys)
        res_df['brys_labels'] = pd.Series(all_bry_labels)
        
        res_df.to_excel(result_file, index = None)
        
    print('--------Ending Evaluating: {}--------'.format(str(datetime.datetime.now())[:19]))
        
    return kappa


def train_model(model, data, lr, num_epochs, examples_per_epoch, tokenizer, save_model = 1, accumulation_steps = 16): #checked
    
    best_metric_so_far = None
    best_model = 'lr{}_bd_{}_ratio_{}_chunk_{}_run_{}.bert'.format(lr, examples_per_epoch, bry_candidate_ratio, predict_as_chunk, run_ix)
    
    for i in range(num_epochs):
        
        train_loader = get_one_bert_epoch_data(data, examples_per_epoch, tokenizer)
        optimizer = AdamW(model.parameters(), lr = lr)
        lr_scheduler = get_scheduler(
            "constant",
            optimizer=optimizer,
            num_warmup_steps=0,
        )
        print('-------start training epoch {}-time:{}------'.format(i+1,str(datetime.datetime.now())[:19]))
        model.train()
        train_one_epoch(model, train_loader, lr_scheduler, optimizer, accumulation_steps = accumulation_steps)
        lr = lr * 0.8
    
        print('--------now evaluating on valid set----------')
        model.eval()
        valid_performance = evaluate_BERT_model(model, data, test_type='valid')      
        
        if best_metric_so_far is None or best_metric_so_far < valid_performance:
            
            old_valid_performance = best_metric_so_far
            best_metric_so_far = valid_performance

            if os.path.exists(best_model):
                os.remove(best_model)
                print('---old model removed---')

            print('---Best valid_performance has been updated from {} to {}---, new best model saved'.format(round(old_valid_performance, 4) if old_valid_performance is not None else None, round(best_metric_so_far,4)))
            torch.save(model,best_model)
            
        else:
            print('---Old valid_performance {} > New valid_performance {}---'.format(round(best_metric_so_far, 4), round(valid_performance, 4)))
            print('No improvement detected compared to last validation round, early stop is triggered.')
            model = torch.load(best_model)
            break   
            
            
    print('--------now testing on unseen prompt {}----------'.format(None))
    evaluate_BERT_model(model, data, test_type = 'test')

    if os.path.exists(best_model) and save_model !=1:
        os.remove(best_model)
        



if __name__ == "__main__":
    
    parser = argparse.ArgumentParser(description="This is a description")
    parser.add_argument('--num_epochs',dest='num_epochs',required = True,type = int)
    parser.add_argument('--save_model',dest='save_model',required = False,type = int)
    parser.add_argument('--learning_rate',dest='learning_rate',required = True,type = float) 
    parser.add_argument('--data_file', dest='data_file', required = True, type = str)  
    parser.add_argument('--examples_per_epoch',dest='examples_per_epoch',required = True,type = int)
    parser.add_argument('--predict_as_chunk',dest='predict_as_chunk',required = False,type = int)
    parser.add_argument('--bry_candidate_ratio',dest='bry_candidate_ratio', required = False,type = float)
    parser.add_argument('--run_ix',dest='run_ix', required = True,type = str)

    args = parser.parse_args()  

    
    num_epochs = args.num_epochs
    save_model = args.save_model if args.save_model is not None else 0
    lr = args.learning_rate
    data_file = args.data_file
    examples_per_epoch = args.examples_per_epoch
    predict_as_chunk = 1
    bry_candidate_ratio = 1.0
    run_ix = args.run_ix
    
    
    print('num_epochs: {}'.format(num_epochs))
    print('save_model: {}'.format(True if save_model == 1 else False))
    print('learning_rate: {}'.format(lr))
    print('data_file: {}'.format(data_file))
    print('examples_per_epoch: {}'.format(examples_per_epoch))
    print('predict_as_chunk: {}'.format(predict_as_chunk))
    print('bry_candidate_ratio: {}'.format(bry_candidate_ratio))
    print('run_ix: {}'.format(run_ix))
    
    
    #if predict_as_chunk == 1:
    
    bry = SentenceTransformer('all-mpnet-base-v2',device = 'cuda' if torch.cuda.is_available() else 'cpu')

    bry_model = TriBertForBoundaryDetection(#self, 
                model = bry,
                num_epoch = 10,
                data_file =  args.data_file,
                learning_rate = lr,
                examples_per_epoch = 3000,
                prototype_size = 1,
                save_model = 0,
                bry_topK = 7,
                bry_candidate_ratio = bry_candidate_ratio,
                description = 'ratio_' + str(bry_candidate_ratio) + '_' + str(predict_as_chunk)+ '_' + str(run_ix)
    )
    
    # Bry_model.train()  The boundary detection module has been removed from this code.
    # So no need to train Bry_model model.
    
    
    data = pd.read_excel(data_file)
    device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu") 
    model = AutoModelForSequenceClassification.from_pretrained("gpt2", num_labels = 3)
    model.to(device)
    tokenizer = AutoTokenizer.from_pretrained("gpt2")
    tokenizer.pad_token = tokenizer.eos_token
    
    train_model(model, data, lr, num_epochs, examples_per_epoch, tokenizer, save_model = save_model, accumulation_steps = 16) 
    
    