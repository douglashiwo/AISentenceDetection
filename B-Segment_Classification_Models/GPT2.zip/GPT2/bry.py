
from nltk.tokenize import sent_tokenize
from scipy.spatial import distance
from sklearn.metrics import accuracy_score
import ml_metrics as metrics
import datetime
import numpy as np
import torch
import time, os
import random
from sentence_transformers import SentenceTransformer, LoggingHandler, losses, InputExample
from torch.utils.data import DataLoader
import pandas as pd
import random
from scipy.spatial import distance
import argparse
import ast
from sklearn.cluster import KMeans
from sklearn.metrics import roc_curve, roc_auc_score, auc,precision_score, f1_score, accuracy_score, recall_score



def get_evaluation_result(predicted, labels, topK = 7): # checked

    tpl = list(zip(predicted,labels))
    result={'precision':[],'recall':[],'f1_score':[]}
    #topK=7
    for p, l in tpl:
        if len(l)==0:
            break
        intersection = set(p[:topK]) & set(l)
        precision = 0.0001+len(intersection) * 1.0 / topK
        recall = 0.0001+len(intersection) * 1.0 / len(l)
       
        result['precision'].append(  precision ) 
        result['recall'].append( recall ) 
        result['f1_score'].append(  2 * precision * recall*1.0 / (precision + recall) )   #f1_score = 2 * precision * recall*1.0 / (precision + recall)
    
    return round( np.mean(result['precision']) ,3), round( np.mean(result['recall']) ,3), round( np.mean(result['f1_score']) ,3)



def get_euclidean_distance(v1,v2): # checked
    return distance.euclidean(v1,v2)
    
    
def auto_detect_K_from_distance_candidates(l, proto_size = 2): #checked
    
    l=sorted(l,reverse=True)
    gap_of_distance= []  
    
    for ix,e in enumerate(l[1:]):  
        pre = np.mean(l[max(0,ix + 1 - proto_size): ix + 1])
        post = np.mean(l[ix + 1: ix + 1 + proto_size])
        #print(l[max(0, ix + 1 - proto_size): ix + 1], '--', l[ix + 1: ix + 1 + proto_size], '--', abs(pre-post), '--', ix + 1)
        gap_of_distance.append((ix + 1, abs(pre - post)))

    auto_detected_topK = sorted(gap_of_distance, key=lambda x: x[1], reverse=True)[0][0]  
    return auto_detected_topK


def get_one_epoch_train_examples(data, examples_per_epoch):  #checked
    res=[]
    for i in range(examples_per_epoch):
        res.append( get_one_triplet_example(data) )
        
    return res
    
    
    
def get_one_triplet_example(data):    #checked
    
    random_session_id = random.choice(list(set(data[data.train_ix == 'train']['session_id'])))    
    types_from_this_session = list(set(data[(data.session_id==random_session_id)&(data.sentence_source!='prompt')]['sentence_source']))
    
    if len(types_from_this_session) >= 2: #two classess, might be api user; user_and_api, api,user_and_api, user
        types_from_this_session = random.sample(types_from_this_session, 2)
        
        type_1_data = data[
                    (data.train_ix == 'train') & 
                    (data.sentence_source == types_from_this_session[0])&
                    (data.session_id == random_session_id)
        ]
        
        type_2_data = data[
                    (data.train_ix == 'train') & 
                    (data.sentence_source == types_from_this_session[1])&
                    (data.session_id == random_session_id)
        ]

        count_type_1 = len(type_1_data)
        count_type_2 = len(type_2_data)
        
        
        if count_type_1>1 and count_type_2>1:
            records = type_1_data.sample(n = 2).to_dict(orient='records')        
            record_11, record_12 = records[0]['sentence_text'], records[1]['sentence_text']
            
            records = type_2_data.sample(n = 2).to_dict(orient='records')              
            record_21, record_22 = records[0]['sentence_text'], records[1]['sentence_text']             
            
            l1,l2 = [record_11,record_12], [record_21,record_22]
            #print('type_1: ', types_from_this_session[0],'type_1: ', types_from_this_session[1])
            
            random.shuffle(l1)
            random.shuffle(l2)
            
            l = l1+l2
            
            if random.random() > 0.5:                  # We are creating triplet here.
                example = InputExample(texts=[l[0], l[1], l[2]])                                
            else:
                example = InputExample(texts=[l[2], l[3], l[1]])
                    
            return example
            
        else: #only one of them larger than 1
            if count_type_1 > 1:
                            
                records = type_1_data.sample(n = 2).to_dict(orient='records')                   
                record_11, record_12 = records[0]['sentence_text'], records[1]['sentence_text']                   
                records = type_2_data.sample(n = 1).to_dict(orient='records')[0]['sentence_text']               
                example = InputExample(texts=[record_11, record_12, records])                    
                
                return example
                
            elif count_type_2 > 1:
            
                records = type_2_data.sample(n = 2).to_dict(orient='records')                   
                record_11, record_12 = records[0]['sentence_text'], records[1]['sentence_text']                   
                records = type_1_data.sample(n = 1).to_dict(orient='records')[0]['sentence_text']                   
                example = InputExample(texts=[record_11, record_12, records])                
                
                return example   
            else:
                return get_one_triplet_example(data)
    else:
        return get_one_triplet_example(data)
    
    
    
def get_bry_from_labels(label_list): #checked
    brys = []
    for ix,lbl in enumerate(label_list[:-1]):
        if label_list[ix] != label_list[ix+1]:
            brys.append(ix+1)
            
    return brys


def get_sessions_essays_brys(df):   #checked
    all_essays = []
    all_brys = []
    all_labels= []
    all_sessions = list(df['session_id'])

    res=[]
    for e in all_sessions:
        if e not in res:
            res.append(e)
    all_sessions = res    

    for session in all_sessions:
        single_essay = df[df.session_id==session].sort_values(by = 'sent_id', ascending=True)['sentence_text'].tolist()
        single_label = df[df.session_id==session].sort_values(by = 'sent_id', ascending=True)['label'].tolist()
        single_brys = get_bry_from_labels( single_label ) 

        
        all_essays.append(single_essay)
        all_brys.append(single_brys)  
        all_labels.append(single_label)
        
    return all_sessions, all_essays, all_brys, all_labels




class TriBertForBoundaryDetection():
    def __init__(self, 
                model,
                num_epoch,
                data_file,
                learning_rate,
                examples_per_epoch,
                prototype_size=1,
                save_model=0,
                bry_topK=7,
                bry_candidate_ratio=1.0,
                description = None
                
    ):
        
        self.model = model
        self.num_epoch = num_epoch
        self.data_file = data_file
        self.data = pd.read_excel(data_file)
        self.learning_rate = learning_rate
        self.initial_learning_rate = learning_rate
        self.examples_per_epoch = examples_per_epoch
        self.prototype_size = prototype_size
        self.save_model = save_model
        self.bry_topK = bry_topK
        self.bry_candidate_ratio = bry_candidate_ratio
        self.description = description
        
         
        print('******** Parameters of the Bry_Detection TriBert ********')   
        
        print('num_epochs: {}'.format(self.num_epoch))
        print('prototype_size: {}'.format(self.prototype_size))  
        print('save_model: {}'.format(True if self.save_model == 1 else False))
        print('learning_rate: {}'.format(self.learning_rate))
        print('data_file: {}'.format(self.data_file))
        print('examples_per_epoch: {}'.format(self.examples_per_epoch))
        print('Boundary_topK_number: {}'.format(self.bry_topK))
        print('Bry_Candidate_ratio: {}'.format(self.bry_candidate_ratio))
               
        print('*****END_END_END Parameters of the Bry_Detection TriBert END_END_END****')
    
    
    def predict_boundary_for_one_essay(self, sents): #checked: using the current boundary

        distance_result=[]
        sents_emb = []
        for sent in sents:
            emb = self.model.encode([sent]).flatten()
            sents_emb.append(emb)   

        for i in range(len(sents_emb)-1):
            emb1 = sents_emb[max(i + 1 - self.prototype_size, 0): i + 1]
            emb2 = sents_emb[i + 1: i + 1 + self.prototype_size]
            
            p1 = np.mean(emb1, axis=0)
            p2 = np.mean(emb2, axis=0)
            dist = get_euclidean_distance(p1, p2)
            distance_result.append(dist)
       
        boundary = sorted([(dist, ix+1) for ix, dist in enumerate(distance_result)], key = lambda x:x[0], reverse = True)     
        ranked_boundary, distances = [ix for dist,ix in boundary], [dist for dist,ix in boundary]
        topk_value = auto_detect_K_from_distance_candidates(distances)    
        auto_boundary = sorted([ix for dist,ix in boundary][:topk_value], reverse=False ) 
        
        
        return sorted(ranked_boundary[ :int(  len(ranked_boundary) * self.bry_candidate_ratio  )]), ranked_boundary
    
    
    
    def train(self):     # checked
    
        best_metric_so_far = None
        best_model = 'Bry_Detect_lr{}_bd_{}_{}_{}.bert'.format(self.learning_rate, self.examples_per_epoch, self.prototype_size, self.description)

        for i in range(self.num_epoch):
            print('---------Epoch {} ----time: {}'.format(i + 1, str(datetime.datetime.now())[:19]))

            train_examples = get_one_epoch_train_examples(self.data, self.examples_per_epoch)
            train_dataloader = DataLoader(train_examples, shuffle = True, batch_size = 1)
            train_loss = losses.TripletLoss(model = self.model, triplet_margin = 1) # euclidean distance

            self.model.fit(
                train_objectives = [(train_dataloader, train_loss)],
                epochs = 1,
                scheduler = 'Constantlr',
                weight_decay = 0.01,
                show_progress_bar = False,#True,
                warmup_steps = 0,
                optimizer_params = {'lr': self.learning_rate}
            )
            self.learning_rate = self.learning_rate * 0.8

            print('--------now evaluating on valid set----------')
            performance = self.evaluate_model(test_type = 'valid')#evaluate_model performance

            if best_metric_so_far is None or best_metric_so_far < performance:

                old_performance = best_metric_so_far
                best_metric_so_far = performance

                if os.path.exists(best_model):
                    os.remove(best_model)
                    print('---old model removed---')

                print('---Best performance has been updated from {} to {}---, new best model saved'.format(round(old_performance, 4) if old_performance is not None else None, round(best_metric_so_far,4)))
                torch.save(self.model,best_model)

            else:
                print('---Old performance {} > New performance {}---'.format(round(best_metric_so_far, 4), round(performance, 4)))
                print('No improvement detected compared to last validation round, early stop is triggered.')
                self.model = torch.load(best_model)
                break

        print('--------now testing on unseen prompt {}----------'.format(None))
        self.evaluate_model(test_type = 'test')

        if os.path.exists(best_model) and self.save_model !=1:
            os.remove(best_model)
            
            
    def evaluate_model(self, test_type):  # checked
        print('--------Start Evaluating: {}--------'.format(str(datetime.datetime.now())[:19]))
        if test_type == 'valid':
            prompt_data = self.data[
                #(self.data.essayset != targetprompt)
                #&
                (self.data.train_ix == 'valid') & (self.data.sentence_source!='prompt')
                #&
                #(self.data.rn_ratio > 0.81)
            ]
        elif test_type == 'test':  # that is 'test' type on unseen prompt
            prompt_data = self.data[
                (self.data.train_ix == 'test') & (self.data.sentence_source!='prompt') #& (self.data.rn_ratio > 0.96)
            ]
            
        
        #all_predicted_brys = [] 
        all_ranked_brys = [] 
        all_sessions, all_essays, all_bry_labels, all_labels = get_sessions_essays_brys(prompt_data)
        all_top_brys = []
        
        
        for essay in all_essays:
            
            top_boundaries, ranked_boundaries = self.predict_boundary_for_one_essay(essay)#, representation_dic) # A Standard List
            all_ranked_brys.append(ranked_boundaries)
            all_top_brys.append(top_boundaries)
            
        precision, recall, f1_score = get_evaluation_result(all_ranked_brys, all_bry_labels, topK = self.bry_topK)
            
        print('--------------------{}ing------------------------'.format(test_type))
        print('Precision: {}'.format(precision))
        print('Recall: {}'.format(recall))
        print('f1_score: {}'.format(f1_score))
        
               
        """
        if test_type == 'test':
            result_file = 'Bry_Order_and_auto_predict_lr_{}_predicted_results_{}_{}_{}.xlsx'.format(self.initial_learning_rate, self.examples_per_epoch, self.prototype_size, self.description)
            res_df = pd.DataFrame()
            
            res_df['session_id'] = pd.Series(all_sessions)
            res_df['essay_sents'] = pd.Series(all_essays)
            res_df['labels'] = pd.Series(all_labels)
            res_df['top_brys'] = pd.Series(all_top_brys)
            res_df['bry_labels'] = pd.Series(all_bry_labels)
            res_df['ranked_brys'] = pd.Series(all_ranked_brys)
            
            res_df.to_excel(result_file, index = None)
        
        """           
            
        print('--------Ending Evaluating: {}--------'.format(str(datetime.datetime.now())[:19]))
            
        return f1_score







if __name__ == "__main__":
    
    parser = argparse.ArgumentParser(description="This is a description")
    parser.add_argument('--num_epoch',dest='num_epoch',required = True, type = int)
    parser.add_argument('--prototype_size',dest='prototype_size',required = False, type = int)
    parser.add_argument('--save_model',dest='save_model',required = False, type = int)
    parser.add_argument('--learning_rate',dest='learning_rate',required = True, type = float) 
    parser.add_argument('--data_file', dest='data_file', required = True, type = str)  
    parser.add_argument('--examples_per_epoch',dest='examples_per_epoch',required = True, type = int)

    args = parser.parse_args()  
    
    data = pd.read_excel(args.data_file)
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    model = SentenceTransformer('all-mpnet-base-v2',device = device)#, device='cpu' )
       
    bry_model = TriBertForBoundaryDetection(#self, 
                model = model,
                num_epoch = 10,
                data_file =  args.data_file,
                learning_rate = args.learning_rate,
                examples_per_epoch = 3000,
                prototype_size = 1,
                save_model = 0,
                bry_topK = 7
    )
    
    bry_model.train()
    
    # Ranked_brys, Auto_brys = bry_model.predict_boundary_for_one_essay(sents)
    

    
    